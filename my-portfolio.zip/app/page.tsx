import dynamic from "next/dynamic";
import { Hero } from "@/components/sections/Hero";
import { About } from "@/components/sections/About";
import { SectionSkeleton } from "@/components/ui/SectionSkeleton";

// Everything below the fold is code-split into its own JS chunk via
// next/dynamic. `ssr: true` (the default) keeps full server-rendered HTML
// for SEO and no-JS visitors — this only changes how the *client* fetches
// the JS needed to hydrate each section, so the Hero's chunk stays small
// and isn't competing with embla-carousel / framer-motion parsing on load.
const Timeline = dynamic(() => import("@/components/sections/Timeline").then((m) => m.Timeline), {
  loading: () => <SectionSkeleton heightClass="h-[520px]" />,
});
const Projects = dynamic(() => import("@/components/sections/Projects").then((m) => m.Projects), {
  loading: () => <SectionSkeleton heightClass="h-[420px]" />,
});
const Gallery = dynamic(() => import("@/components/sections/Gallery").then((m) => m.Gallery), {
  loading: () => <SectionSkeleton heightClass="h-[460px]" />,
});
const NextPlans = dynamic(() => import("@/components/sections/NextPlans").then((m) => m.NextPlans), {
  loading: () => <SectionSkeleton heightClass="h-[380px]" />,
});
const Contact = dynamic(() => import("@/components/sections/Contact").then((m) => m.Contact), {
  loading: () => <SectionSkeleton heightClass="h-[320px]" />,
});

export default function Home() {
  return (
    <main>
      <Hero />
      <About />
      <Timeline />
      <Projects />
      <Gallery />
      <NextPlans />
      <Contact />
    </main>
  );
}
