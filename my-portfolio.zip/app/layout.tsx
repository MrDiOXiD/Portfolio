import type { Metadata, Viewport } from "next";
import { vazirmatn, jetbrainsMono } from "@/lib/fonts";
import { Aurora } from "@/components/ui/Aurora";
import { ChronoSpine } from "@/components/ui/ChronoSpine";
import { SectionNav } from "@/components/ui/SectionNav";
import { profile } from "@/content/profile";
import "./globals.css";

const siteUrl = "https://heydariamir.ir";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: `${profile.name} — ${profile.role}`,
  description: profile.googleIndexDescription,
  keywords: [profile.name, profile.role, "Next.js", "Full-Stack Developer", "پورتفولیو", "توسعه‌دهنده فول‌استک" , "NestJs","typescript","javascript","امیر محمد حیدری","امیر حیدری","برنامه نویس","طراح وب"],
  alternates: { canonical: "/" },
  openGraph: {
    title: `${profile.name} — ${profile.role}`,
    description: profile.heroSubtext,
    url: siteUrl,
    siteName: profile.name,
    locale: "fa_IR",
    type: "website",
    images: ["/opengraph-image"],
  },
  twitter: {
    card: "summary_large_image",
    title: `${profile.name} — ${profile.role}`,
    description: profile.heroSubtext,
    images: ["/opengraph-image"],
  },
  robots: { index: true, follow: true },
};

export const viewport: Viewport = {
  themeColor: "#071416",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const personJsonLd = {
    "@context": "https://schema.org",
    "@type": "Person",
    name: profile.name,
    jobTitle: profile.role,
    url: siteUrl,
    email: `mailto:${profile.contact.email}`,
    sameAs: [profile.contact.github],
  };

  return (
    <html lang="fa" dir="rtl" className={`${vazirmatn.variable} ${jetbrainsMono.variable}`}>
      <body className="font-sans">
        <script
          type="application/ld+json"
          // eslint-disable-next-line react/no-danger
          dangerouslySetInnerHTML={{ __html: JSON.stringify(personJsonLd) }}
        />
        {/* <a
          href="#hero"
          className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-50 focus:rounded-full focus:bg-turquoise focus:px-4 focus:py-2 focus:text-sm focus:font-bold focus:text-bed"
        >
          رفتن به محتوای اصلی
        </a> */}
        <Aurora />
        <ChronoSpine />
        <SectionNav />
        {children}
      </body>
    </html>
  );
}
